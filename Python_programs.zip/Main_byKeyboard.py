import requests
import json

def ollama_chat_simple(api_key, message, model="cogito-2.1:671b"):
    
    url = "https://ollama.com/api/chat"
    
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }
    
    data = {
        "model": model,
        "messages": [
            {"role": "user", "content": message}
        ],
        "temperature": 0.7,
        "max_tokens": 500,
        "stream": False  # STREAMING DISABILITATO
    }
    
    try:
        response = requests.post(url, json=data, headers=headers)
        response.raise_for_status()
        
        result = response.json()
        
        # CORREZIONE: Ollama usa 'message' non 'choices'
        if 'message' in result:
            return result['message']['content']
        elif 'response' in result:
            return result['response']
        else:
            # Per sicurezza, prova diversi formati
            return f"Formato risposta non riconosciuto: {json.dumps(result, indent=2)[:200]}..."
        
    except requests.exceptions.HTTPError as e:
        return f"Errore HTTP: {e.response.status_code} - {e.response.text}"
    except Exception as e:
        return f"Errore: {str(e)}"

# Esempio di uso
stringHeader = "ti passo una frase che potrebbe contenere qualcosa di offensivo/aggressivo. restituiscimi una frase alternativa, più pacifica ed educata. se il contenuto va gia bene non alterarla. rispondi solo con la frase prodotta senza nessun proemio."

if __name__ == "__main__":
    API_KEY = "4b343ffcd5f34c2f9e4366f80bc33f74.HVAAdJLUzPjH2tVX0s9vsAxk"
    
    print("💬 Chat semplice con Ollama Cloud")
    print("Scrivi 'exit' per uscire\n")
    
    while True:
        user_input = stringHeader + input()
        if user_input.lower() == 'exit':
            break
            
        response = ollama_chat_simple(API_KEY, user_input)
        print(f"\nfrase pacificata: {response}\n")